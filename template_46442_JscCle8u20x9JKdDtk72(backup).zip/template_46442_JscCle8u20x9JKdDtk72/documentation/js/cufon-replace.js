Cufon.replace('h1 , h2 , nav ul li a', { fontFamily: 'Lobster' });
Cufon.replace('h1 small , h3', { fontFamily: 'Raleway' });